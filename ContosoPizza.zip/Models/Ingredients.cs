namespace ContosoPizza.Models;

public class Ingredients{
    public string? Name {get; set;}
    public decimal? Calories {get; set;}
    public string? Origin {get; set;}
    public bool? IsGlutenFree {get; set;}
}